import asyncio, os, json, logging
from aiogram import Bot, Dispatcher, F
from aiogram.types import (Message, CallbackQuery, InlineKeyboardMarkup,
    InlineKeyboardButton, LabeledPrice, PreCheckoutQuery, SuccessfulPayment,
    WebAppInfo, MenuButtonWebApp)
from aiogram.filters import CommandStart

logging.basicConfig(level=logging.INFO)
BOT_TOKEN = os.getenv("BOT_TOKEN", "PASTE_NEW_TOKEN_HERE")
WEBAPP_URL = os.getenv("WEBAPP_URL", "https://claude.ai/artifact/KAwp17pVeY7yQQGpdHhtEK")

# 1 GRAM = 1 Star (настраивается)
RATE = 1

PACKAGES = [
    {"stars": 50,  "gram": 50,  "label": "50 GRAM",  "emoji": "💎"},
    {"stars": 150, "gram": 150, "label": "150 GRAM", "emoji": "💎💎"},
    {"stars": 500, "gram": 500, "label": "500 GRAM", "emoji": "💎💎💎"},
]

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# Простое хранилище балансов (в продакшне — база данных)
balances: dict[int, float] = {}

def get_balance(uid: int) -> float:
    return balances.get(uid, 0.0)

def add_balance(uid: int, amount: float):
    balances[uid] = balances.get(uid, 0.0) + amount

def packages_kb() -> InlineKeyboardMarkup:
    rows = []
    for i, p in enumerate(PACKAGES):
        rows.append([InlineKeyboardButton(
            text=f"{p['emoji']} {p['label']} — {p['stars']} ⭐",
            callback_data=f"buy:{i}"
        )])
    rows.append([InlineKeyboardButton(text="💰 Мой баланс", callback_data="balance")])
    return InlineKeyboardMarkup(inline_keyboard=rows)

@dp.message(CommandStart())
async def cmd_start(msg: Message):
    await bot.set_chat_menu_button(
        chat_id=msg.chat.id,
        menu_button=MenuButtonWebApp(text="💳 Открыть кошелёк", web_app=WebAppInfo(url=WEBAPP_URL))
    )
    kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(text="💳 Открыть кошелёк", web_app=WebAppInfo(url=WEBAPP_URL))
    ]])
    await msg.answer(
        f"👋 Привет, <b>{msg.from_user.first_name}</b>!\n\n"
        f"💎 Твой GRAM-кошелёк готов.\n"
        f"Баланс: <b>{get_balance(msg.from_user.id):.0f} GRAM</b>\n\n"
        f"Пополни через Telegram Stars ⬇️",
        parse_mode="HTML",
        reply_markup=kb
    )

@dp.message(F.text == "💳 Пополнить")
@dp.message(F.text.lower().in_({"пополнить", "top up", "/topup"}))
async def cmd_topup(msg: Message):
    await msg.answer(
        "Выбери пакет GRAM для пополнения:",
        reply_markup=packages_kb()
    )

@dp.callback_query(F.data == "balance")
async def cb_balance(cb: CallbackQuery):
    bal = get_balance(cb.from_user.id)
    await cb.message.edit_text(
        f"💎 Баланс: <b>{bal:.0f} GRAM</b>\n\nПополнить:",
        parse_mode="HTML",
        reply_markup=packages_kb()
    )

@dp.callback_query(F.data.startswith("buy:"))
async def cb_buy(cb: CallbackQuery):
    idx = int(cb.data.split(":")[1])
    p = PACKAGES[idx]
    await cb.answer()
    await bot.send_invoice(
        chat_id=cb.from_user.id,
        title=f"Пополнение {p['label']}",
        description=f"Зачислит {p['gram']} GRAM на твой кошелёк",
        payload=json.dumps({"uid": cb.from_user.id, "gram": p["gram"]}),
        currency="XTR",           # Telegram Stars
        prices=[LabeledPrice(label=p["label"], amount=p["stars"])],
        provider_token="",         # для Stars всегда пустой
    )

@dp.pre_checkout_query()
async def pre_checkout(pcq: PreCheckoutQuery):
    await pcq.answer(ok=True)

@dp.message(F.successful_payment)
async def on_payment(msg: Message):
    data = json.loads(msg.successful_payment.invoice_payload)
    uid  = data["uid"]
    gram = data["gram"]
    add_balance(uid, gram)
    bal = get_balance(uid)
    await msg.answer(
        f"✅ Оплата прошла!\n\n"
        f"💎 Зачислено: <b>+{gram} GRAM</b>\n"
        f"💰 Новый баланс: <b>{bal:.0f} GRAM</b>",
        parse_mode="HTML",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="💳 Открыть кошелёк", web_app=WebAppInfo(url=WEBAPP_URL))
        ]])
    )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
